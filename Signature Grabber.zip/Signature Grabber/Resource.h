#ifndef RESOURCE_H
#define RESOURCE_H

#define IDR_MANIFEST1 102
#define IDD_ABOUT 103

#endif
